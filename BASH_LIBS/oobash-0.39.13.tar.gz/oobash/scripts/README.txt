Do NOT delete this directory!
It is used by Script.generator and it is in your PATH
after sourcing the oobash.source file.
There also is a hidden directory .completions that contains 
the option autocompletion files for your scripts.
