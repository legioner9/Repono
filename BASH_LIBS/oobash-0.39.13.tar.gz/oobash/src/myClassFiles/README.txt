Do NOT delete this directory!
It is used by Class.generator.
