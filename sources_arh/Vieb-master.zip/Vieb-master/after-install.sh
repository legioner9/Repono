ln -sf /opt/Vieb/vieb /usr/bin/vieb
chmod 4755 '/opt/Vieb/chrome-sandbox' || true
update-mime-database /usr/share/mime || true
update-desktop-database /usr/share/applications || true
