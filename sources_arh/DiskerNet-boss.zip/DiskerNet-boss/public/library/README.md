# ALT Default storage directory for library

Remove `public/library/http*` and `public/library/cache.json` from `.gitignore` if you forked this repo and want to commit your library using git.

## Clearing your cache

To clear everything, delete all directories that start with `http` or `https` and delete cache.json

To clear only stuff from domains you don't want, delete all directories you don't want that start with `http` or `https` and DON'T delete cache.json

