/* eslint-disable no-global-assign */
require = require('esm')(module/*, options*/);
module.exports = require('./app.js');
/* eslint-enable no-global-assign */
